<html>
<head>
</head>
<body>
	<div>
		<?php echo $boom; ?>
	</div>
</body>
</html>