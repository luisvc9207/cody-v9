<div data-id="" onclick="deletePrivateLog(this);" class="ppitem ppdel">
	<i class="fa fa-trash-can"></i>
</div>
<div data-id="" onclick="quotePrivateLog(this);" class="ppitem ppquote">
	<i class="fa fa-reply"></i>
</div>