<?php
$hlang['flood_mute'] = 'Flodanje zabrani';
$hlang['word_mute'] = 'Loš rječnik zabrani';
$hlang['word_kick'] = 'Loš rječnik izbaci';
$hlang['spam_mute'] = 'Spamovanje zabrani';
$hlang['spam_ghost'] = 'Spam duh';
$hlang['spam_ban'] = 'Spamovanje blokiraj';
$hlang['mute'] = 'Blokiraj konverzaciju';
$hlang['ban'] = 'Zabrani';
$hlang['kick'] = 'Izbaci';
$hlang['flood_kick'] = 'Poplavni udarac';
$hlang['vpn_kick'] = 'Vpn udarac';
$hlang['main_mute'] = 'Glavni zvuk';
$hlang['private_mute'] = 'Privatno isključivanje zvuka';
$hlang['ghost'] = 'Duh';
$hlang['warn'] = 'Warning';
?>