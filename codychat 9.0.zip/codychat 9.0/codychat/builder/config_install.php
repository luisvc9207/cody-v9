<?php
require(__DIR__ . '/../system/database.php');
require(__DIR__ . '/../system/settings.php');
require(__DIR__ . '/../system/controller.php');
require(__DIR__ . '/../system/function.php');
require(__DIR__ . '/../system/function_all.php');
require(__DIR__ . '/../system/function_redis.php');
?>