<?php
$lang['youtube_key'] = 'musickraze api key';
$lang['youtube_access'] = 'Rank required to use';
?>