<?php
require('../../../system/config.php');
$addons = addonsDetails('aps_music');
$client_id = $addons['custom1'];
$client_secret = $addons['custom2'];
$redirect_uri = $setting['domain'] . '/addons/aps_music/system/login.php';

if (isset($_GET['code'])) {
    $code = $_GET['code'];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://accounts.spotify.com/api/token');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'grant_type' => 'authorization_code',
        'code' => $code,
        'redirect_uri' => $redirect_uri,
        'client_id' => $client_id,
        'client_secret' => $client_secret,
    ]));

    $response = curl_exec($ch);
    curl_close($ch);

    $spot = json_decode($response, true);

    if (isset($spot['access_token'])) {
        setcookie('access_token', $spot['access_token'], time() + 36000, '/');
        header("Location: $redirect_uri");
        exit;
    }
}
if (isset($_COOKIE['access_token'])) {
     echo '<script>window.close();</script>';
	 die();
}
?>
