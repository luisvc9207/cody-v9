<div id="vip_spin" class="hidden pad15 centered_element">
	<p><i class="fa fa-spinner fa-spin vip_spinner success"></i></p>
	<p class="text_small vpad15"><?php echo $lang['vip_redirect']; ?></p>
</div>