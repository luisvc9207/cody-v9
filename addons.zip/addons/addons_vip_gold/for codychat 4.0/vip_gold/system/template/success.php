<div class="pad20 centered_element">
	<div class="vip_icons success">
		<i class="fa fa-check-circle"></i>
	</div>
	<div class="pad15">
		<?php echo $lang['vip_success']; ?>
	</div>
</div>