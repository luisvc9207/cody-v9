<div class="pad20 centered_element">
	<div class="vip_icons error">
		<i class="fa fa-times-circle"></i>
	</div>
	<div class="pad15">
		<?php echo $lang['vip_fail']; ?>
	</div>
</div>