<div class="sub_list_item blist">
	<div class="sub_list_pcontent text_reg bold vpad5">
		<?php echo $boom; ?>
	</div>
	<div class="sub_list_icon">
		<i class="fa fa-check success"></i>
	</div>
</div>