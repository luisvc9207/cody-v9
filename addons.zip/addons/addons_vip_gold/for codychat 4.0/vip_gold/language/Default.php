<?php
$lang['vip_buy'] = 'Buy vip';
$lang['vip_plan'] = 'Plans';
$lang['vip_transaction'] = 'Transaction';
$lang['vip_mode_status'] = 'Vip module status';
$lang['vip_take'] = 'View plans';
$lang['vip_submit'] = 'Checkout';
$lang['vset1'] = '7 days price';
$lang['vset2'] = '1 month price';
$lang['vset3'] = '3 months price';
$lang['vset4'] = '1 year price';
$lang['vset5'] = 'Lifetime price';
$lang['vip_order'] = 'VIP Order';
$lang['vip_add'] = 'Add VIP';
$lang['vip_cancel'] = 'Cancel VIP';
$lang['vip_manage'] = 'Manage VIP';
$lang['vip_life'] = 'Lifetime';
$lang['end_date'] = 'End date';
$lang['vip_confirm'] = 'Do you really want to cancel  VIP plan of this user. This action cannot be undone.';
$lang['vip_back'] = 'Back';
$lang['vip_myself'] = 'Myself';
$lang['vip_other'] = 'Someone else';
$lang['vip_who'] = 'Member username';
$lang['vip_forwho'] = 'Who is this VIP membership for ?';
$lang['vip_feature_title'] = 'VIP features';
$lang['vip_feature_text'] = 'Our VIP access award you feature that are not accessible to regular members. Here is a list of some advantages that you receive when you are VIP.';
$lang['vip_guest'] = 'Sorry only registered members can subscribe to VIP membership please register an account in order to purchase VIP membership and access some great extra features.';
$lang['vip_plan_title'] = 'Our VIP plans';
$lang['vip_plan_text'] = 'Select one of the following plan to get instant VIP access and take advantage off our VIP features.';
$lang['vplan1'] = '7 Days VIP Membership';
$lang['vplan2'] = '1 Month VIP Membership';
$lang['vplan3'] = '3 Months VIP Membership';
$lang['vplan4'] = '1 Year VIP Membership';
$lang['vplan5'] = 'Lifetime VIP Membership';

// list of feature

$feature[1] = 'Feature one here';
$feature[2] = 'Feature two here';
$feature[3] = 'Feature three here';
$feature[4] = 'Feature four here';
$feature[5] = 'Feature five here';
$feature[6] = '';
$feature[7] = '';
$feature[8] = '';
$feature[9] = '';
$feature[10] = '';
?>