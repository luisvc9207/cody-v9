<script data-cfasync="false">
$(document).ready(function(){
	boomAddCss('addons/adnoyer/files/adnoyer.css');
});
</script>