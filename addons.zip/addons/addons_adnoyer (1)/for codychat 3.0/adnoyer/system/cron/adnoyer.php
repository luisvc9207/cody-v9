<?php
require(__DIR__ . '/../../../../system/config_version.php');
require(__DIR__ . '/' . $boom_version . '/' . basename(__FILE__));
?>