<?php
$lang['status'] = 'adnoyer status';
$lang['adnoyer_delay'] = 'Auto send message delay';
$lang['adnoyer_hide'] = 'Hide this bot content for';
$lang['adnoyer_mlogs'] = 'Minimum post between message';
$lang['adnoyer_users'] = 'Minimum user required in a room';
$lang['adnoyer_content'] = 'Content';
$lang['adnoyer_title'] = 'Title';
?>