<?php
$lang['status'] = 'Status adnoyer';
$lang['adnoyer_delay'] = 'Délais entre les message bot';
$lang['adnoyer_hide'] = 'Ne pas montrer les message pour rang';
$lang['adnoyer_mlogs'] = 'Nombre minimum de post entre message';
$lang['adnoyer_users'] = 'Nombre minimum membre dans la chambre';
$lang['adnoyer_content'] = 'Contenu';
$lang['adnoyer_title'] = 'Titre';
?>