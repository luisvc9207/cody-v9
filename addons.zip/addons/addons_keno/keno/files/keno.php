<?php
if(boomAllow($addons['addons_access'])){
?>
<script data-cfasync="false">
var kenoVersion = <?php echo $setting['version']; ?>;
var kenoMax = <?php echo $addons['custom1']; ?>;
var kenoSpeed = <?php echo $addons['custom2']; ?>;
var kenoMode = 1;
</script>
<script data-cfasync="false">
openKeno = function(){
	$.ajax({
		url: "addons/keno/system/keno.php",
		type: "post",
		cache: false,
		dataType: 'json',
		data: { 
		},
		beforeSend: function(){
			prepareLeft(400);
		},
		success: function(response){
			showLeftPanel(response.content, 400, response.title);
		},
		error: function(){
			callError(system.error);
		}
	});
}

var selectedNumbers = []; 
var waitKeno = 0;

highlightResultNumbers = function(resultNumbers, onFinish) {
	let index = 0;
	let kwin = 0;
	$('.kodds').removeClass('bback');
	const interval = setInterval(() => {
		if (index < resultNumbers.length) {
			const number = resultNumbers[index];
			const $numberElement = $(`.keno_number[data-number="${number}"]`);
			if ($numberElement.hasClass('keno_sel')) {
				$numberElement.addClass('keno_good');
				kenoSoundGood();
				kwin++;
				$('.kodds').removeClass('bback');
				$('.kodds'+kwin).addClass('bback');
			} 
			else {
				$numberElement.addClass('keno_pick');
				kenoSound();
			}
			index++;
		} 
		else {
			clearInterval(interval);
			if (typeof onFinish === 'function') {
					onFinish();
			}
		}
	}, kenoSpeed);
}

kenoSwitch = function(t){
	if(t == 1){
		$('.keno_gelem').removeClass('fhide');
		$('.keno_relem').addClass('fhide');
		kenoMode = 1;
	}
	else if(t == 2){
		$('.keno_relem').removeClass('fhide');
		$('.keno_gelem').addClass('fhide');
		kenoMode = 2;
	}
}

showKenoOdds = function(){
	var newKenoOdds = selectedNumbers.length;
	$('.keno_odds').addClass('hidden');
	$('#keno_odds'+newKenoOdds).removeClass('hidden');
}

kenoPlus = function(){
	var curkeno = parseInt($('#keno_bet').attr('data'));
	var newcurkeno;
	if(curkeno < 5){
		newcurkeno = curkeno + 1;
	}
	else if(curkeno < 10){
		newcurkeno = curkeno + 5;
	}
	else if (curkeno < 100) {
		newcurkeno = curkeno + 10;
	} 
	else if (curkeno >= 100 && curkeno < 250) {
		newcurkeno = curkeno + 25;
	} 
	else if (curkeno >= 250 && curkeno < 1000) {
		newcurkeno = curkeno + 50;
	}
	if (newcurkeno <= kenoMax) {
		$('#keno_bet').attr('data', newcurkeno).text(newcurkeno);
		$('.kenoodds').each(function() {
			var odds = parseFloat($(this).attr('data-odds'));
			var updatedValue = newcurkeno * odds;
			$(this).text(updatedValue);
		});
	}
}

kenoMinus = function(){
	var curkeno = parseInt($('#keno_bet').attr('data'));
	var newcurkeno;
	if (curkeno > 250) {
		newcurkeno = curkeno - 50;
	} 
	else if (curkeno > 100 && curkeno <= 250) {
		newcurkeno = curkeno - 25;
	} 
	else if (curkeno > 10 && curkeno <= 100) {
		newcurkeno = curkeno - 10;
	}
	else if (curkeno === 10){
		newcurkeno = 5;
	}
	else if(curkeno <= 5 && curkeno > 1){
		newcurkeno = curkeno - 1;
	}
	if (newcurkeno >= 1) {
		$('#keno_bet').attr('data', newcurkeno).text(newcurkeno);
		$('.kenoodds').each(function() {
			var odds = parseFloat($(this).attr('data-odds'));
			var updatedValue = newcurkeno * odds;
			$(this).text(updatedValue);
		});
	}
}

kenoSoundGood = function(){
	if(boomSound(1)){
		document.getElementById('keno2_sound').play();
	}
}
kenoSound = function(){
	if(boomSound(1)){
		document.getElementById('keno1_sound').play();
	}
}
resetKenoModal = function() {
    selectedNumbers = []; 
    $('.keno_number').attr('data-sel', 0);
    $('.keno_number').removeClass('keno_sel keno_good keno_pick');
    $('.keno_odds').addClass('hidden');
	waitKeno = 0;
	kenoMode = 1;
}
kenoBalance = function(b) {
	$('#keno_gold').text(b.gold);
	$('#keno_ruby').text(b.ruby);
}
kenoPayout = function(b) {
	$('#keno_payout').text(b);
}
takeKenoBalance = function(b){
	if(kenoMode == 1){
		var nkbal = parseInt($('#keno_gold').text()) - parseInt(b);
		$('#keno_gold').text(nkbal);
	}
	if(kenoMode == 2){
		var nkbal = parseInt($('#keno_ruby').text()) - parseInt(b);
		$('#keno_ruby').text(nkbal);
	}
}
validKeno = function(b){
	if(kenoMode == 1){
		var kbalance = parseInt($('#keno_gold').text());
	}
	if(kenoMode == 2){
		var kbalance = parseInt($('#keno_ruby').text());
	}
	if(kbalance >= parseInt(b)){
		return true;
	}
	else {
		return false;
	}
}
kenoBet = function() {
	if(waitKeno == 0){
		var kbet = $('#keno_bet').attr('data');
		if(!validKeno(kbet)){
			return false;
		}
		else {
			$('.keno_number').removeClass('keno_good').removeClass('keno_pick');
			if (selectedNumbers.length > 1 && selectedNumbers.length < 11) {
				waitKeno = 1;
				$.ajax({
					url: "addons/keno/system/action.php",
					type: "post",
					cache: false,
					dataType: 'json',
					data: { 
						kenoselect: selectedNumbers,
						kenobet: kbet,
						kenotype: kenoMode,
					},
					beforeSend: function(){
						kenoPayout(0);
					},
					success: function(response){
						if(response.code == 1){
							takeKenoBalance(kbet);
							highlightResultNumbers(response.result, function() {
								kenoBalance(response.balance);
								kenoPayout(response.win);
								waitKeno = 0;
							});
						}
						else {
							waitKeno = 0;
						}
					},
					error: function(){
						waitKeno = 0;
					}
				});
			}
		}
	}
}
kenoClear = function(){
	if(waitKeno == 0){
		selectedNumbers = []; 
		$('.keno_number').attr('data-sel', 0);
		$('.keno_number').removeClass('keno_sel');
		$('.keno_number').removeClass('keno_pick');
		$('.keno_number').removeClass('keno_good');
		$('.kodds').removeClass('bback');
		kenoPayout(0);
		showKenoOdds();
	}
}

kenoHelp = function(){
	$.post('addons/keno/system/keno_help.php', {
		}, function(response) {
			overModal(response);
	});
}

$(document).ready(function(){
	boomAddCss('addons/keno/files/keno.css');
	
	if(kenoVersion > 6){
		appGameMenu('addons/keno/files/keno.png', 'Keno', 'openKeno();');
	}
	else {
		appLeftMenu('table-cells', 'Keno', 'openKeno();', 'keno_addons_menu');
	}	
	$(document).on('click', '.keno_number', function(){
		if(waitKeno == 0){
			kenoPayout(0);
			if ($('.keno_number').hasClass('keno_good') || $('.keno_number').hasClass('keno_pick')){
				$('.keno_number').removeClass('keno_good').removeClass('keno_pick');
			}
			else {
				var number = $(this).attr('data-number');
				var selectedCount = selectedNumbers.length;
				var kenocount = 0;

				if ($(this).attr('data-sel') == 1) {
					$(this).removeClass('keno_sel').attr('data-sel', 0);
					selectedNumbers = selectedNumbers.filter(function(item){
						return item != number;
					});
					showKenoOdds();
				} 
				else {
					if (selectedCount < 10) {
						$(this).addClass('keno_sel').attr('data-sel', 1);
						selectedNumbers.push(number);
						showKenoOdds();
					}
				}
			}
		}
	});
});
</script>
<?php } ?>