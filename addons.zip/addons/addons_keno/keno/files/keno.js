const canvas = document.getElementById('kenoCanvas');
const ctx = canvas.getContext('2d');

const rows = 8;
const cols = 10;
const numbers = [];
let selectedNumbers = [];
let drawnNumbers = [];

const cellWidth = 80;
const cellHeight = 60;
const boardOffsetX = 50;
const boardOffsetY = 50;

for (let i = 1; i <= 80; i++) {
    numbers.push(i);
}

function drawKenoBoard() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            let number = row * cols + col + 1;
            let x = col * cellWidth + boardOffsetX;
            let y = row * cellHeight + boardOffsetY;

            // Highlight selected numbers
            if (selectedNumbers.includes(number)) {
                ctx.fillStyle = 'lightblue';
                ctx.fillRect(x, y, cellWidth, cellHeight);
            }

            // Highlight drawn numbers
            if (drawnNumbers.includes(number)) {
                ctx.fillStyle = 'lightgreen';
                ctx.fillRect(x, y, cellWidth, cellHeight);
            }

            // Draw number
            ctx.fillStyle = 'black';
            ctx.strokeStyle = 'black';
            ctx.strokeRect(x, y, cellWidth, cellHeight);
            ctx.fillText(number, x + cellWidth / 2 - 10, y + cellHeight / 2 + 5);
        }
    }
}

// Handle selecting numbers
canvas.addEventListener('click', function(event) {
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    const col = Math.floor((x - boardOffsetX) / cellWidth);
    const row = Math.floor((y - boardOffsetY) / cellHeight);
    const clickedNumber = row * cols + col + 1;

    if (!selectedNumbers.includes(clickedNumber) && selectedNumbers.length < 10) {
        selectedNumbers.push(clickedNumber);
    } else if (selectedNumbers.includes(clickedNumber)) {
        selectedNumbers = selectedNumbers.filter(num => num !== clickedNumber);
    }

    drawKenoBoard();
});

function drawRandomNumbers() {
    drawnNumbers = [];
    const availableNumbers = [...numbers]; // Clone the array

    while (drawnNumbers.length < 20) {
        const randomIndex = Math.floor(Math.random() * availableNumbers.length);
        const drawnNumber = availableNumbers.splice(randomIndex, 1)[0]; // Remove from available
        drawnNumbers.push(drawnNumber);
    }

    checkMatches();
    drawKenoBoard();
}

document.getElementById('drawButton').addEventListener('click', drawRandomNumbers);

// Check how many selected numbers match the drawn numbers
function checkMatches() {
    const matches = selectedNumbers.filter(num => drawnNumbers.includes(num));
    alert(`You matched ${matches.length} numbers!`);
}

drawKenoBoard();