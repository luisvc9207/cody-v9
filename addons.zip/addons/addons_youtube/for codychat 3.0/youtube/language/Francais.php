<?php
$lang['youtube_key'] = 'Clé api Youtube';
$lang['youtube_access'] = 'Rang requis pour utiliser';
?>