<?php
$lang['youtube_key'] = 'Youtube api key';
$lang['youtube_access'] = 'Rank required to use';
?>