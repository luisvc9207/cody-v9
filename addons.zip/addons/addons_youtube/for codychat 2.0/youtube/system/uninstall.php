<?php
if(!defined('BOOM')){
	die();
}
?>