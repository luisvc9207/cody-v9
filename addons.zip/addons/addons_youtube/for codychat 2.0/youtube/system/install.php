<?php
if(!defined('BOOM')){
	die();
}
$ad = array(
	'name' => 'youtube',
	'access'=> 10,
	'custom1'=> '',
	'custom2'=> 16,
	'custom3'=> 20,
	);
?>