<?php
$lang['youtube_key'] = 'Youtube api key';
$lang['youtube_access'] = 'Rang requis pour utiliser';
?>