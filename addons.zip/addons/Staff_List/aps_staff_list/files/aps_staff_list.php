<?php
/*===============================================*
 |                                               |
 |   Developer        :  [AMEER_PS]              |
 |                                               |
 |   addon name       :  [staff list]            |
 |                                               |
 |   Version          :  [3.0]                   |
 |                                               |
 |   Codychat version :  [CODYCHAT >= 4]         |
 |                                               |
 *===============================================*/
?>
<?php if(boomAllow($addons['addons_access'])){ ?>
<script data-cfasync="false">
openListStaff = function(){
	$.ajax({
		url: "addons/aps_staff_list/system/box/staff_list.php",
		type: "post",
		cache: false,
		dataType: 'json',
		data: { 
		},
		beforeSend: function(){
			prepareLeft(400);
		},
		success: function(response){
			showLeftPanel(response.content, 400, response.title);
		},
		error: function(){
			callError(system.error);
		}
	});
}
$(document).ready(function(){
	appLeftMenu('star', 'Staff List', 'openListStaff();');
});
</script>
<?php } ?>