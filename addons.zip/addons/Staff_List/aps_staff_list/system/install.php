<?php
if(!defined('BOOM')){
	die();
}

$ad = array(
	'name' => 'aps_staff_list',
	'access'=> 100,
	);

?>