<?php
$load_addons = 'aps_staff_list';
require_once('../../../../system/config_addons.php');
$empty = emptyZone($lang['no_data']);
$data_list = $mysqli->query("
	SELECT user_id, user_name,user_role, user_mood, user_color, last_action, user_bot, user_status, user_font, user_rank, user_tumb
	FROM `boom_users`
	WHERE user_bot = 0 
	ORDER BY `user_rank` DESC, `user_name` ASC 
");
mysqli_close($mysqli);
$ranks = rankList();
$rankContent = [];

foreach ($ranks as $rank) {
    $rankContent[$rank] = '';
}

if ($data_list->num_rows > 0) {
    while ($list = $data_list->fetch_assoc()) {
        $rank = $list['user_rank'];
        if ($rank >= 70 && $rank <= 100) {
            $rankContent[$rank] .= createUserlistStaff($list);
        }
    }
}
ob_start();
?>
<div class="pad10 rtl_elem">
    <div class="reg_menu_container tmargin10">
        <div class="reg_menu">
            <ul>
                <?php foreach ($ranks as $rank){ ?>
                    <?php if ($rank >= 70 && $rank <= 100){ ?>
                        <li class="reg_menu_item<?php echo $rank == 70 ? ' rselected' : ''; ?>" data="staff_list" data-z="<?php echo strtolower($rank); ?>"><?php echo staffTitle($rank); ?></li>
					<?php } ?>
                <?php } ?>
            </ul>
        </div>
    </div>
    <div id="staff_list">
        <?php foreach ($ranks as $rank){ ?>
            <?php if ($rank >= 70 && $rank <= 100){ ?>
                <div id="<?php echo strtolower($rank); ?>" class="reg_zone vpad5<?php echo $rank != 70 ? ' hide_zone' : ''; ?>">
                    <?php echo $rankContent[$rank] == '' ? $empty : $rankContent[$rank]; ?>
                    <div class="clear"></div>
                </div>
            <?php } ?>
        <?php } ?>
    </div>
</div>

<?php
$res['content'] = ob_get_clean();
$res['title'] = 'Staff List';

echo boomCode(1, $res);
?>