<?php
$load_addons = 'aps_staff_list';
require('../../../system/config_addons.php');
if(!canManageAddons()){
	die();
}
if(isset($_POST['set_staff_access'])){
	$access = escape($_POST['set_staff_access']);
	$mysqli->query("UPDATE boom_addons SET addons_access = '$access' WHERE addons = '$load_addons'");
	redisUpdateAddons($load_addons);
	echo 5;
	die();
}
?>