<?php
function staffTitle($value) {
	global $data, $lang;
    $icon = systemRank($value, 'chat_rank');
    $title = rankTitle($value);    
    return $title . ' ' . $icon;
}
function createUserlistStaff($list){
	return '<div data="'.$list['user_id'].'" class="get_info avtrig bhover user_item">
			<div class="user_item_icon icrank">' . userListRank($list) . '</div><div class="user_item_avatar"><img class="avav acav" src="' . myAvatar($list['user_tumb']) . '"/></div>
			<div class="user_item_data">
				<p class="username ' . myColorFont($list) . '">' . $list["user_name"] . '</p>
				<p class="list_mood">' . $list['user_mood'] . '</p>
			</div>
		</div>';
}
?>