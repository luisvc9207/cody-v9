<?php
$load_addons = 'aps_staff_list';
require('../../../system/config_addons.php');
if(!canManageAddons()){
	die();
}
?>
<?php echo elementTitle($addons['addons'], 'loadLob(\'admin/setting_addons.php\');'); ?>
<div class="page_full">
    <div>
        <div class="tab_menu">
            <ul>
                <li class="tab_menu_item tab_selected" data="codeit" data-z="codeit_settings"><?php echo $lang['settings']; ?></li>
            </ul>
        </div>
    </div>
    <div class="page_element">
        <div class="tpad15">
            <div id="codeit">
                <div id="codeit_settings" class="tab_zone">
                    <div class="setting_element ">
                        <p class="label"><?php echo $lang['limit_feature']; ?></p>
                        <select id="set_staff_access">
                            <?php echo listRank($addons['addons_access']); ?>
                        </select>
                    </div>
					<div class="setting_element">
						<label class="success"><i class="fa fa-key"></i> Thank you for using our services <a target="_blank" href="https://store.yildiz-host.com/">Yldiz Host</a></label>
					</div>
                    <button onclick="saveStaffList();" type="button" class="tmargin10 reg_button theme_btn"><i class="fa fa-floppy-o"></i> <?php echo $lang['save']; ?></button>
                </div>
            </div>
        </div>
        <div class="config_section">
            <script data-cfasync="false" type="text/javascript">
                saveStaffList = function() {
                    $.post('addons/aps_staff_list/system/action.php', {
                        set_staff_access: $('#set_staff_access').val(),
                    }, function(response) {
                        if (response == 5) {
                            callSuccess(system.saved);
                        } else {
                            callError(system.error);
                        }
                    });
                }
            </script>
        </div>
    </div>
</div>