<?php
$lang['gifs'] = 'Gifs';
$lang['stickers'] = 'Stickers';
$lang['max_stickers'] = 'Nombre de stickers';
$lang['max_gifs'] = 'Nombre de gifs';
$lang['giphy_key'] = 'Clé api Giphy';
?>