<?php
if(!defined('BOOM')){
	die();
}
$ad = array(
	'name' => 'paintit',
	'access'=> 100,
	'custom1'=> 1,
	'custom2'=> 1,
	);
?>