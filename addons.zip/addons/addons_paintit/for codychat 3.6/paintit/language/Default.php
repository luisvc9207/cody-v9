<?php
$lang['paint_main'] = 'Allow in chat';
$lang['paint_private'] = 'Allow in private';
?>