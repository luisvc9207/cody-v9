<?php
if(!defined('BOOM')){
	die();
}
$ad = array(
	'name' => 'paintit',
	'access'=> 11,
	'custom1'=> 1,
	'custom2'=> 1,
	);
?>