<?php
$load_addons = 'aps_welcome_bot';
require('../../../system/config_addons.php');

if(!canManageAddons()){
	die();
}

?>
<?php echo elementTitle($addons['addons'], 'loadLob(\'admin/setting_addons.php\');'); ?>
<div class="page_full">
    <div>
        <div class="tab_menu">
            <ul>
                <li class="tab_menu_item tab_selected" data="codeit" data-z="codeit_settings"><?php echo $lang['settings']; ?></li>
            </ul>
        </div>
    </div>
    <div class="page_element">
        <div class="tpad15">
            <div id="codeit">
                <div id="codeit_settings" class="tab_zone">
                    <div class="setting_element">
						<p class="label">Welcome message</p>
						<input id="set_welcome" class="full_input" value="<?php echo $addons['custom1']; ?>" type="text"/>
					</div>
                    <button onclick="saveWelcome();" type="button" class="tmargin10 reg_button theme_btn"><i class="fa fa-floppy-o"></i> <?php echo $lang['save']; ?></button>
                </div>
            </div>
        </div>
        <div class="config_section">
            <script data-cfasync="false" type="text/javascript">
                saveWelcome = function() {
                    $.post('addons/aps_welcome_bot/system/action.php', {
                        set_welcome: $('#set_welcome').val(),
                    }, function(response) {
                        if (response == 5) {
                            callSuccess(system.saved);
                        } else {
                            callError(system.error);
                        }
                    });
                }
            </script>
        </div>
    </div>
</div>