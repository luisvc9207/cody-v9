<?php
$load_addons = 'aps_welcome_bot';
require_once('../../../system/config_addons.php');

if(isset($_POST['set_welcome'])){
	if(!canManageAddons()){
		die();
	}
	$set_welcome = escape($_POST['set_welcome']);
	$mysqli->query("UPDATE boom_addons set custom1 = '$set_welcome' WHERE addons = '$load_addons' ");
	redisUpdateAddons('aps_welcome_bot');
	echo 5;
	die();
}
?>