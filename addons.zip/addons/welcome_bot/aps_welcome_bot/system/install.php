<?php
if(!defined('BOOM')){
	die();
}
$ad = array(
	'name' => 'aps_welcome_bot',
	'custom1'=> 'welcome to my chat',
	);
$mysqli->query("ALTER TABLE `boom_users` ADD `wellcome_bot` INT(11) NOT NULL DEFAULT 0;");
$mysqli->query("ALTER TABLE `boom_users` MODIFY COLUMN `wellcome_bot` INT(11) NOT NULL DEFAULT 0;");
?>