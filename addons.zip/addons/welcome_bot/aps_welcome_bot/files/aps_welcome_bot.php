<?php
/*===============================================*
 |                                               |
 |   Developer        :  [AMEER_PS]              |
 |                                               |
 |   addon name       :  [welcome bot]           |
 |                                               |
 |   Version          :  [2.0]                   |
 |                                               |
 |   Codychat version :  [CODYCHAT 4.X]          |
 |                                               |
 *===============================================*/
if($data['wellcome_bot'] == 0){
	$mysqli->query("UPDATE boom_users set wellcome_bot = 1 WHERE user_id = {$data['user_id']}");
	redisUpdateUser($data['user_id']);
	systemPostPrivate($data['user_id'], $addons['custom1']);
}
?>

