<?php
function searchUsersList($boom){
	global $lang;
	return '<div class="sub_list_item"  id="pvip'. $boom['user_id'] . '">
			<div class="sub_list_avatar">
				<img class="admin_user'. $boom['user_id'] . '" src="'. myavatar($boom['user_tumb']) .'"/>
			</div>
			<div class="sub_list_content hpad5">
				<p class="bold '. $boom['user_color'] . ' bellpis">'. $boom['user_name'] . '</p>
				<p class="text_xsmall sub_text">Original Rank: '. userListRank($boom, 'pro_ranking') .'</p>
			</div>
			<div onclick="editThisUserRank('. $boom['user_id'] . ');" class="sub_list_option">
				<i class="fa fa-edit"></i>
			</div>
		</div>';
}
function getUserRankEdits($id){
	global $mysqli;
	$user = array();
	$getuser = $mysqli->query("SELECT * FROM rank_editor WHERE user_id = '$id'");
	if($getuser->num_rows > 0){
		$user = $getuser->fetch_assoc();
	}
	return $user;
}