<?php
$load_addons = 'rank_editor';
require_once('../../../system/config_addons.php');
$id = escape($_POST['target']);
if (!boomAllow($addons['addons_access'])) {
	die();
}
?>
<style>
input[type="file"] {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0,0,0,0);
    border: 0;
}
.custom-file-upload {
    border: 1px solid #ccc;
    display: inline-block;
    padding: 6px 12px;
    cursor: pointer;
    width: 100%;
    text-align: center;
    background: #002d39;
    color: white;
    border-radius: 3px;
}
</style>
<div class="brow">
	<div class="bcell border_bottom">
		<div class="modal_top_menu">
			<div class="bcell_mid hpad15">
				<p class="label"><i class='fa fa-trophy bgrad35'></i> <?php echo $lang['rank_editor']; ?></p>
			</div>
			<div class="modal_top_menu_empty">
			</div>
			<div class="cancel_modal cover_text modal_top_item">
				<i class="fa fa-times"></i>
			</div>
		</div>
	</div>
</div>
<div class="pad10">
	<div class="setting_element">
		<p class="label"><?php echo $lang['set_rank_edit']; ?></p>
		<div class="admin_search">
			<label for="set_img_edit_rank" class="custom-file-upload">
				<i id="new_rank_ico" data="cloud-upload" class="fa fa-cloud-upload"></i> Upload Image
			</label>
			<input onchange="exSaveNewUserRanks(<?php echo $id; ?>);" id="set_img_edit_rank" type="file" />
		</div>
	</div>
	<p class="label"><?php echo $lang['back_default_rank']; ?></p>
	<button style="width:100%;margin: 10px 0 0 0;" onclick="exBackDefaultUserRanks(<?php echo $id; ?>);" class="reg_button delete_btn"><i class="fa fa-trash"></i> <?php echo $lang['default_rank']; ?></button>
</div>