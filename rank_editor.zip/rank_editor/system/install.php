<?php
if(!defined('BOOM')){
	die();
}
if(boomAllow(100)){
	$ad = array(
	'name' => 'rank_editor',
	'access'=> 100,
	);
}
$mysqli->query("ALTER TABLE boom_users ADD rank_img varchar(100) NOT NULL DEFAULT ''");

/* $mysqli->query("CREATE TABLE IF NOT EXISTS `rank_editor` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`user_id` int(11) NOT NULL,
	`rank_img` varchar(100) NOT NULL,
	PRIMARY KEY (`id`))");
?> */