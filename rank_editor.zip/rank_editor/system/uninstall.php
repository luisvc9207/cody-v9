<?php
if(boomAllow(100)){
}
?>