<?php
$lang['edit_ranks'] = 'تعديل الرتب';
$lang['write_username'] = 'ابحث عن اسم عضو لتعديل رتبته';
$lang['rank_editor'] = 'تعديل الرتب';
$lang['set_rank_edit'] = 'اختر صورة جديدة لرتبة العضو';
$lang['default_rank'] = 'الرتبه الاصلية';
$lang['back_default_rank'] = 'هل تريد اعادة الرتبه الاصلية لهذا العضو ؟';
?>