<?php
include(addonsLang('rank_editor'));

$user_Rank      = array();
$find_user_Rank = $mysqli->query("SELECT * FROM boom_users");
if ($find_user_Rank->num_rows > 0) {
    while ($row = mysqli_fetch_object($find_user_Rank)) {
        array_push($user_Rank, $row);
    }
}
mysqli_free_result($find_user_Rank);


// json.
$jsonco = [
    'RankUser' => $user_Rank
];

?>
<script data-cfasync="false" type="text/javascript">
    window.RankData = <?php echo json_encode($jsonco, JSON_HEX_TAG); ?>;
    const configEditor = {
        attributes: true,
        childList: true,
        characterData: true
    };
    $(document).ready(function() {
        const targetEditor = $("#chat_right_data")[0];
        const targetEditor2 = $("#chat_logs_container")[0];
        $(document).on('click', '.get_info', function() {
            const profile = $(this).attr('data');
            const targetPro = $('#large_modal #large_modal_content')[0];
            const observerProfileNewRank = new MutationObserver(function(mutations) {
                mutations.forEach((mutation) => {
                    const profileTINFO = document.querySelectorAll('.profile_tinfo');
                    profileTINFO.forEach((item) => {
                        let $node = $(item); // jQuery set
                        getUserRank(profile).forEach((Rank) => {
                            if (Rank.rank_img !== '') {
                                $node.children().children().each(function() {
                                    if ($(this).hasClass('pro_rank')) {
                                        $(this).children('img').remove();
                                        $(this).prepend('<img src="default_images/rank/' + Rank.rank_img + '" class="pro_ranking">');
                                    }
                                });
                            }else{
                                $node.children().children().each(function() {
                                    if ($(this).hasClass('pro_rank')) {
                                        $(this).children('img').remove();
                                        $(this).prepend(`<img title="${systemRankTitle(Rank.user_rank)}" src="${systemRankIcon(Rank.user_rank)}" class="pro_ranking"/>`);
                                    }
                                });
                            }
                        });
                    });
                });
                $.when($.post('addons/rank_editor/system/api.php', {
                    update_data: 1,
                    token: utk
                }).then(function(response) {
                    RankData = JSON.parse(response);
                }));
            });
            observerProfileNewRank.observe(targetPro, configEditor);
        });
        const observerUserListRank = new MutationObserver(function(mutations) {
            mutations.forEach((mutation) => {
                const userRank = document.querySelectorAll('.user_item');
                userRank.forEach((item) => {
                    let $nodes3 = $(item); // jQuery set
                    const userID = $($nodes3).attr('data-id');
                    getUserRank(userID).forEach((Rank) => {
                        if (Rank.rank_img !== '') {
                            $nodes3.children().each(function() {
                                if ($(this).hasClass('icrank')) {
                                    $(this).remove();
                                }
                            });
                            $nodes3.append('<div class="user_item_icon icrank"><img src="default_images/rank/' + Rank.rank_img + '" class="list_rank"></div>');
                        }
                    });

                });
            });
            $.when($.post('addons/rank_editor/system/api.php', {
                update_data: 1,

                token: utk
            }).then(function(response) {
                RankData = JSON.parse(response);
            }));
        });
        const observerChatNodeRank = new MutationObserver(function(mutations) {
            mutations.forEach((mutation) => {
                const chatNodes = document.querySelectorAll('.avtrig');
                chatNodes.forEach((item) => {
                    let $ch_node = $(item); // jQuery set
                    const userIDS = $($ch_node).attr('data-id');
                    let $main_msg = $(item).parent();
                    let $rank_place = $main_msg.find('.cname');
                    getUserRank(userIDS).forEach((node) => {
                        if (node.rank_img !== '') {
                            $rank_place.children().each(function() {
                                if ($(this).hasClass('chat_rank')) {
                                    $(this).remove();
                                }
                            });
                            $rank_place.prepend(chatRankyTemp(node));
                        }
                    });
                });
            });
            $.when($.post('addons/rank_editor/system/api.php', {
                update_data: 1,

                token: utk
            }).then(function(response) {
                RankData = JSON.parse(response);
            }));
        });
        observerUserListRank.observe(targetEditor, configEditor);
        observerChatNodeRank.observe(targetEditor2, configEditor);
        getUserRank = function(_UserID) {
            const tmpRankList = [];
            const RankForUser = RankData.RankUser.filter((item) => item.user_id === _UserID);
            RankForUser.forEach((item) => tmpRankList.push(RankData.RankUser.find((st) => st.user_id === item.user_id)));
            tmpRankList.sort((a, b) => a.user_id - b.user_id);
            return tmpRankList;
        };
        chatRankyTemp = function(myRank) {
            return `<img src="default_images/rank/${myRank.rank_img}" class="chat_rank">`;
        };
    });
</script>