<?php
$lang['edit_ranks'] = 'Edit Ranks';
$lang['write_username'] = 'Write user name here to edit his rank';
$lang['rank_editor'] = 'Rank Editor';
$lang['set_rank_edit'] = 'Set new rank image for this user';
$lang['default_rank'] = 'Default Rank';
$lang['back_default_rank'] = 'Do you want back to default rank image ?';
?>