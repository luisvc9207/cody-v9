<?php
$load_addons = 'rank_editor';
require_once('../../../system/config_addons.php');

function exNewDynm1(){
    global $data, $mysqli, $lang, $cody;
    $user_data      = array();
    $find_user_Rank = $mysqli->query("SELECT user_id, rank_img, user_rank FROM boom_users");
    if ($find_user_Rank->num_rows > 0) {
        while ($row = mysqli_fetch_object($find_user_Rank)) {
            array_push($user_data, $row);
        }
    }
    mysqli_free_result($find_user_Rank);

    // json.
    $jsonco = [
        'RankUser' => $user_data
    ];
    echo json_encode($jsonco, JSON_HEX_TAG);
}

if (isset($_POST['update_data'])) {
    echo exNewDynm1();
}
