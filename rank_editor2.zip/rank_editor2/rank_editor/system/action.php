<?php
$load_addons = 'rank_editor';
require_once('../../../system/config_addons.php');

function exDynmThisAddon2()
{
    global $mysqli, $data, $lang, $addons;

    $createuser = '';
    $target = escape($_POST['search_edit_ranks']);
    if (!boomAllow($addons['addons_access'])) {
        die();
    }
    $result = $mysqli->query("SELECT * FROM boom_users WHERE user_name LIKE '$target%'");
    if ($result->num_rows > 0) {
        while ($list = $result->fetch_assoc()) {
            $createuser .= searchUsersList($list);
        }
    } else {
        return emptyZone('User not found..');
    }
    return $createuser;
}

function exDynPanelGifts3(){
	global $data, $lang, $mysqli;
    ini_set('memory_limit', '128M');
    $info = pathinfo($_FILES["edit_rank_photo"]["name"]);
    $extension = $info['extension'];
    $origin = escape(filterOrigin($info['filename']) . '.' . $extension);
    $id = escape($_POST['edit_rank_id']);
    $user = userDetails($id);
    if (!boomAllow($addons['addons_access'])) {
        die();
    }
    if (fileError()) {
        echo 1;
        die();
    }
    if (isFile($extension)) {
        echo 1;
        die();
    }
    if (isMusic($extension)) {
        echo 1;
        die();
    }
    $imginfo = getimagesize($_FILES["edit_rank_photo"]["tmp_name"]);
    if ($imginfo !== false) {
        $file_name = $_FILES["edit_rank_photo"]["name"];
        $unlinklink = BOOM_PATH . '/default_images/rank/' . $file_name;
        if (file_exists($unlinklink)) {
            unlink($unlinklink);
        }
        $unlinklink = BOOM_PATH . '/default_images/rank/' . $user["rank_img"];
        if (file_exists($unlinklink)) {
            unlink($unlinklink);
            
        }
        if (!boomAllow($addons['addons_access'])) {
            die();
        }
        move_uploaded_file($_FILES["edit_rank_photo"]["tmp_name"], BOOM_PATH . '/default_images/rank/' . $file_name);
        $mysqli->query("UPDATE boom_users SET rank_img = '$file_name' WHERE user_id = '{$user['user_id']}'");
        redisUpdateUser($user['user_id']);
        echo 5;
        die();
        
    }
}

function exDynmThisAddon3()
{
    global $mysqli, $data, $lang, $addons;

    $target = escape($_POST['del_user_rank']);
    $user = userDetails($target);
    if (!boomAllow($addons['addons_access'])) {
        die();
    }
    $unlinklink = BOOM_PATH . '/default_images/rank/' . $user["rank_img"];
    if (file_exists($unlinklink)) {
        unlink($unlinklink);
        
    }
    $mysqli->query("UPDATE boom_users SET rank_img = '' WHERE user_id = '{$user['user_id']}'");
    redisUpdateUser($user['user_id']);
    return 1;
}

if (isset($_POST['search_edit_ranks'])) {
    echo exDynmThisAddon2();
    die();
}


if (isset($_FILES['edit_rank_photo'], $_POST['edit_rank_id'])) {
    echo exDynPanelGifts3();
}


if (isset($_POST['del_user_rank'])) {
    echo exDynmThisAddon3();
    die();
}
