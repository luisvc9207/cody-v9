<?php
function rank_editor_uninstall() {
    global $data;
    
    try {
        $stmt = $data->prepare("DELETE FROM boom_addons WHERE addons = ?");
        $result = $stmt->execute(['rank_editor']);
        return $result;
        
    } catch (Exception $e) {
        error_log("Rank Editor Uninstall Error: " . $e->getMessage());
        return false;
    }
}
?>