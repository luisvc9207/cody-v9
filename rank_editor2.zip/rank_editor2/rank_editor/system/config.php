<?php
$load_addons = 'rank_editor';
require_once('../../../system/config_addons.php');
?>
<?php echo elementTitle($addons['addons'], 'loadLob(\'admin/setting_addons.php\');'); ?>
<div class="page_full">
    <div>
        <div class="tab_menu">
            <ul>
                <li class="tab_menu_item tab_selected" data="korsy" data-z="edit_ranks"><i class="fa fa-trophy"></i> <?php echo $lang['edit_ranks']; ?></li>
            </ul>
        </div>
    </div>
    <div class="page_element">
        <div id="korsy" class="tpad15">
            <div id="edit_ranks" class="tab_zone">
                <div class="setting_element ">
                    <p class="label"><i class="fa fa-search"></i> <?php echo $lang['write_username']; ?></p>
                    <div class="admin_search">
                        <div class="admin_input bcell">
                            <input class="full_input" id="user_edit_rank" type="text">
                        </div>
                        <div id="search_edit_rank" class="admin_search_btn default_btn">
                            <i class="fa fa-search" aria-hidden="true"></i>
                        </div>
                    </div>
                </div>
                <div id="edit_ranks_result">
                </div>
            </div>
        </div>
        <div class="config_section">
            <script data-cfasync="false" type="text/javascript">
                $(document).on('click', '#search_edit_rank', function() {
                    validSearch = $('#user_edit_rank').val().length;
                    if (validSearch >= 1) {
                        $.post('addons/rank_editor/system/action.php', {
                            search_edit_ranks: $('#user_edit_rank').val(),
                            token: utk,
                        }, function(response) {
                            $('#edit_ranks_result').html(response);
                        });
                    } else {
                        callSaved(system.tooShort, 3);
                    }
                });
                editThisUserRank = function(user) {
                    $.post('addons/rank_editor/system/edit_rank.php', {
                        target: user,
                        token: utk,
                    }, function(response) {
                        if (response == 0) {
                            callSaved(system.error, 3);
                        } else {
                            showEmptyModal(response, 350);
                        }
                    });
                }
                var waitexEditMyGift = 0;
                exSaveNewUserRanks = function(id) {
                    var edit_file_data = $("#set_img_edit_rank").prop("files")[0];
                    if ($("#set_img_edit_rank").val() === "") {
                        callSaved(system.noFile, 3);
                    } else {
                        if (waitexEditMyGift == 0) {
                            waitexEditMyGift = 1;
                            uploadIcon('new_rank_ico', 1);
                            var form_data = new FormData();
                            form_data.append("edit_rank_id", id)
                            form_data.append("edit_rank_photo", edit_file_data)
                            form_data.append("token", utk)
                            $.ajax({
                                url: "addons/rank_editor/system/action.php",
                                dataType: 'json',
                                cache: false,
                                contentType: false,
                                processData: false,
                                data: form_data,
                                type: 'post',
                                success: function(response) {
                                    if (response == 1) {
                                        callSaved(system.wrongFile, 3);
                                    } else if (response == 5) {
                                        callSaved(system.saved, 1);
                                    } else {
                                        callSaved('مشكلة بالنظام', 3);
                                    }
                                    waitexEditMyGift = 0;
                                    uploadIcon('new_rank_ico', 2);
                                },
                                error: function() {
                                    callSaved(system.error, 3);
                                    uploadIcon('new_rank_ico', 2);
                                    waitexEditMyGift = 0;
                                }
                            })
                        } else {
                            return false;
                        }
                    }
                }
                exBackDefaultUserRanks = function(id) {
                    $.post('addons/rank_editor/system/action.php', {
                        del_user_rank: id,
                        token: utk,
                    }, function(response) {
                        if (response == 1) {
                            callSaved(system.saved, 1);
                        } else {
                            callSaved(system.error, 3);
                        }
                    });
                }
            </script>
        </div>
    </div>
</div>