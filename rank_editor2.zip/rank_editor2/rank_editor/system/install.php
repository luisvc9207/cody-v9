<?php
function rank_editor_install() {
    global $data;
    
    try {
        // Verificar si ya está instalado
        $check = $data->prepare("SELECT addons_id FROM boom_addons WHERE addons = ?");
        $check->execute(['rank_editor']);
        
        if ($check->rowCount() > 0) {
            return true; // Ya instalado
        }
        
        // Insertar con estructura EXACTA de tu BD
        $stmt = $data->prepare("
            INSERT INTO boom_addons 
            (addons, addons_load, addons_key, addons_access, bot_name, bot_id) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $result = $stmt->execute([
            'rank_editor',                           // addons
            1,                                      // addons_load
            hash('sha256', 'rank_editor_' . time()), // addons_key  
            5,                                      // addons_access
            '',                                     // bot_name
            0                                       // bot_id
            // custom1..custom10 se omiten (valores por defecto)
        ]);
        
        return $result;
        
    } catch (Exception $e) {
        error_log("Rank Editor Install Error: " . $e->getMessage());
        return false;
    }
}
?>